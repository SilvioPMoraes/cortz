import Image from "next/image"
import { CardContent, Card } from "./card"

const Header = () => {
  return (
    <Card>
      <CardContent>
        <Image alt="FWS Barber" src="/logo.png" height={18} width={120} />
      </CardContent>
    </Card>
  )
}

export default Header
