import { Button } from "@/app/_components/ui/button"

const Home = () => {
  return <div>Home Page</div>
}

export default Home
